/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 9, 2018, 3:28 PM
 *Purpose: Celsius Temperature Table
 */

//System Libraries Here
#include <iostream>  //I/O Library
#include <iomanip> //Format Library
using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

// Function Prototypes
double celsius(int);

//Program Execution Begins Here
int main()
{
	cout << "\nTable of Fahrenheit temperatures 0 - 20\n"
		 << "and their Celsius equivalents.\n\n"
		 << "------------------------------\n"
		 << "  Fahrenheit       Celsius\n"
		 << "------------------------------\n";
    
	for (int F = 0; F <= 20; F++)
	{
		cout << "      " << setw(2) << F;
		cout << "          "
			 << setw(3) << celsius(F) << endl;
	}
	cout << endl;
	return 0;
}
/* This function accepts a Fahrenheit temperature as an argument *
 * and returns the temperature converted into Celsius. */

double celsius(int F)
{
	
	return (5.0 * (F - 32))/9;
}

