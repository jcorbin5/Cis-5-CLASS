/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 8, 2018, 7:20 AM
 *Purpose: Markup
 */


//System Libraries Here
#include <iostream> //I/O Library
#include <iomanip> //Format Library
using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions


// Function prototype
double calculateRetail();

//Program Execution Begins Here
int main()
{
	double RetalPrice;
	cout << "This program calculates and displays the retail price of an item.\n";
	RetalPrice = calculateRetail();
	cout << fixed << showpoint << setprecision(2);
	cout << "The retail price of the item is $" << RetalPrice <<endl;
	return 0;
}
/*The function receives the wholesale cost and the markup percentage *
 * as arguments, and return the  retail price of the item*/

double calculateRetail()
{
	double Cost,
		   Markup;

    // Input Validation: only positive values for either the wholesale  
	// cost of the item or the percent markup.
	do
	{
		cout << "What is the item's wholesale cost? ";
		cin  >> Cost;
		if (Cost < 0)
		{
			cout << "Error!\n"
				 << "Wholesale cost must be a positive number.\n";
		}
	} while (!(Cost > 0));
	do
	{
		cout << "What is the item's markup percentage? ";
		cin  >> Markup;
		if (Markup < 0)
		{
			cout << "Error!\n"
				 << "The markup percentage must be a positive number.\n";	
		}
	} while (!(Markup > 0));

	Markup /= 100;
	return Cost * (1 + Markup);
}