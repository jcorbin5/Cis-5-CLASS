/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 9, 2018, 10:21 PM
 *Purpose: Kinetic Energy
 */

//System Libraries Here
#include <iostream> //I/O Library
#include <cmath> //Math functions
using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
double kineticEnergy(int, int);

//Program Execution Begins Here
int main()
{
	int Mass, 		// Mass in kilograms
		Velo;		// Velocity in meters per second

	// Ask user to enter object's mass (in kilograms)
	// and velocity (in meters per second)
	cout << "\nThis program calculates the amount\n"
	     << "of kinetic energy an object has.\n\n"
	     << "Enter the object’s mass (in kilograms): ";
	cin  >> Mass;
	cout << "Enter the object’s velocity (in meters per second): ";
	cin  >> Velo;
	cout << "This object has is "
		 << kineticEnergy(Mass, Velo) << " joules." << endl;
	return 0;
}
/*This function accepts an object’s mass and velocity    *
 * as arguments and returns the amount of kinetic energy *
 * that the object has.*/

double kineticEnergy(int Mass, int Velo)
{   
	return .5 * Mass * pow(Velo, 2);
}