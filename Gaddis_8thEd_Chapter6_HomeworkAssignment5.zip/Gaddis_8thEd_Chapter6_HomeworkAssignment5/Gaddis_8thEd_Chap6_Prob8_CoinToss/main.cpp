/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 9, 2018, 6:49 PM
 *Purpose: Coin Toss
 */

//System Libraries Here
#include <iostream> //I/O Library
using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int cointoss()
{
  int toss = rand()%2 + 1;
  if (toss == 1)
    cout << "heads" << endl;
  else
    cout << "tails" << endl;
  return toss;
}

//Program Execution Begins Here
int main()
{
  srand(time(NULL));
  int heads = 0, tails = 0, tosscount = 0, numtosses = 0;
  cout << "How many times do you want the coin to be tossed? -> ";
  cin >> numtosses;
  cout << endl;
  while (tosscount < numtosses)
  {
    if (cointoss() == 1)
      heads++;
    else
      tails++;
    tosscount++;
  }
  cout << "\nTotal number of heads: "<< heads << endl;
  cout << "\nTotal number of tails: "<< tails << endl;
}

