/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 11, 2018, 2:27 PM
 *Purpose: Overloaded Hospital
 */

//System Libraries Here
#include <iostream> //I/O Library
#include<iomanip> //Format Library
#include<cmath> //Math Functions

using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
double Costs(int numDays, double ratePerday, double lab, double medication);     
double Costs(double lab, double medication);

//Program Execution Begins Here
int main()
{
       int stay;
       double totalIn;
       double totalOut;
       int numDays;
       double ratePerday, lab, medication;
      
       // Get choice of inpatient or outpatient hospital stay
       cout << "You will need to enter a 0 for inpatient stay or a 1 for outpatient stay." << endl;
       cin >> stay;

       // Validate the choice
       while (stay != 0 && stay != 1)
       {
              cout << "Please enter 0 for inpatient stay or a 1 for outpatient stay." << endl;
              cin >> stay;
       }
      
       // Process selection
       switch(stay)
       {
       // Inpatient Stay
       case 0:      
              cout << "Please enter the number of days spent at the hospital: " << endl;
              cin >> numDays;
              cout << "Please enter the hospital's daily rate: " << endl;
              cin >> ratePerday;
      
              cout << "Please enter the charges for labwork: " << endl;
              cin >> lab;
              cout << "Please enter the charges for medications: " << endl;
              cin >> medication;
              totalIn = Costs(numDays, ratePerday, lab, medication);
              cout << "The total inpatient costs are: $" << totalIn << endl;
              break;

       // Outpatient Stay
       case 1:
              cout << "Please enter the charges for labwork: " << endl;
              cin >> lab;
              cout << "Please enter the charges for medications: " << endl;
              cin >> medication;
              totalOut = Costs(lab, medication);
              cout << "The total outpatient costs are: $" << totalOut << endl;
              break;
       }

       system("Pause");
       return 0;
}

// function for Inpatient Stay
double Costs(int numDays, double ratePerday, double lab, double medication)
{
       // Calculate total inpatient costs
       return (numDays * ratePerday) + lab + medication;
}

// function for Outpatient Stay
double Costs(double lab, double medication)
{
       // Calculate total inpatient costs
       return lab + medication;
}