/*
 * File:   main.cpp
 * Author: Justin Corbin
 *Created on November 8, 2018, 12:42 PM
 *Purpose: Falling Distance
 */

//System Libraries Here
#include <iostream> //I/O Library
#include <iomanip> //Format Library
#include <cmath> //Math functions
using namespace std; //namespace I/O stream library created

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
const double GRAVITY = 9.8;

// Function prototypes
double fallingDistance(int);

//Program Execution Begins Here
int main()
{
 	cout << "\nTable of the distances an object falls due\n"
 		 << "to gravity in specific time periods.\n\n"
 		 << "    Time        Distance\n"
 	     << "(in seconds)   (in meters)\n"
 	     << "---------------------------\n";

 	for(int T = 1; T <= 10; T++)
 	{
 		cout << "    " << setw(3) << T << "           "
 			 << fixed << setprecision(0) << setw(4) 
 			 << fallingDistance(T) << endl;
 	}
 	cout << endl;
 	return 0;
}
/* This function accepts an object’s falling time (in seconds) as an argument *
 * and returns  the distance in meters that the object has fallen during that *
 * time interval. */

double fallingDistance(int T)
{
	return .5 * GRAVITY * pow(T, 2);
}

